public interface Test {
    public void doOperation();
    public void checkExceptionInOption();
    public void checkExceptionOnNumbers();
}
