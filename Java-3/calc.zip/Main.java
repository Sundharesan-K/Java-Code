public class Main {
    public static void main(String[] args) {
        Calculator cobj = new Calculator();
        cobj.printWelcomeMessage();
        cobj.showOptions();
        cobj.getOption();
//        cobj.setOperation();
        cobj.getNumbers();
//        cobj.checkExceptionInOption();
//        cobj.callRespectiveObject();
    }
}